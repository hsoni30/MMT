﻿using MMTHSWebApp.DataObjects;
using System.Runtime.Serialization;

namespace MMTHSWebApp.Models
{
   
    public class Customer
    {
        public Customer(CustomerData customerData)
        {
            firstName = customerData.firstName;
            lastName = customerData.lastName;
        }
        //[IgnoreDataMember]  // we nned more time to implement proper structure
        //[JsonIgnore] // we nned more time to implement proper structure       
        public string firstName { get; set; }        
        public string lastName { get; set; }
    }   
    public class ForCustomer
    {
        public string user { get; set; }
        public string customerId { get; set; }        
    }
}
