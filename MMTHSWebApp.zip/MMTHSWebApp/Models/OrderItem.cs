﻿
using MMTHSWebApp.DataObjects;
using System.Collections.Generic;

namespace MMTHSWebApp.Models
{
    public class OrderItem  
    {
        public OrderItem(OrderItemData orderItemData, bool IsGift = false)
        {
            product = IsGift ? "Gift" : orderItemData.product;
            quantity = orderItemData.quantity;
            priceEach =  orderItemData.priceEach;
        }        
        public string product { get; set; }
        public int quantity { get; set; }
        public decimal priceEach { get; set; }

        public static List<OrderItem> GetOrderItems(OrderData orderData)
        {
            var orderDataItems = new OrderItemData().GetOrderItems(orderData);

            List<OrderItem> orderItems = new List<OrderItem>();
            foreach (var orderitemData in orderDataItems)
            {
                orderItems.Add(new OrderItem(orderitemData, orderData.CONTAINSGIFT));
            }
            return orderItems;
        }        
    }
}

