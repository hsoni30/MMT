﻿
using MMTHSWebApp.DataObjects;

namespace MMTHSWebApp.Models
{
    public class OrderItem  
    {
        public OrderItem(OrderItemData orderItemData)
        {
            product = orderItemData.product;
            quantity = orderItemData.quantity;
            priceEach = orderItemData.priceEach;
        }        
        public string product { get; set; }
        public int quantity { get; set; }
        public decimal priceEach { get; set; }
    }
}

