﻿using MMTHSWebApp.DataObjects;
using System;
using System.Collections.Generic;

namespace MMTHSWebApp.Models
{
    public class Order 
    {
        public Order(OrderData orderData, List<OrderItemData> orderItemDatas)
        {
            orderNumber = orderData.orderNumber;
            orderDate = orderData.orderDate;
            deliveryExpected = orderData.deliveryExpected;
            deliveryAddress = "Not Sure It is Same as Customer Address";//not sure from which table to get ;
            orderItems = OrderItem.GetOrderItems(orderItemDatas, orderData.CONTAINSGIFT).ToArray();
        }
        public int orderNumber { get; set; }
        public DateTime orderDate { get; set; }
        public string deliveryAddress { get; set; }        
        public OrderItem[] orderItems { get; set; }       
        public DateTime deliveryExpected { get; set; }
    }  
}
