﻿using MMTHSWebApp.DataConnection;
using MMTHSWebApp.DataObjects;
using System;

namespace MMTHSWebApp.Models
{
    public class Order 
    {
        public Order(OrderData orderData)
        {
            orderNumber = orderData.orderNumber;
            orderDate = orderData.orderDate;
            deliveryExpected = orderData.deliveryExpected;
            deliveryAddress = "Not Sure It is Same as Customer Address";//not sure from which table to get ;
            orderItems = OrderItem.GetOrderItems(orderData).ToArray();
        }
        public int orderNumber { get; set; }
        public DateTime orderDate { get; set; }
        public string deliveryAddress { get; set; }        
        public OrderItem[] orderItems { get; set; }       
        public DateTime deliveryExpected { get; set; }

        public static Order GetOrder(OrderData orderData)
        {
            return (orderData != null)? new Order(orderData): null;
        }
    }  
}
