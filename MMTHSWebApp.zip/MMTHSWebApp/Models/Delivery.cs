﻿using MMTHSWebApp.DataObjects;
using Newtonsoft.Json;
namespace MMTHSWebApp.Models
{
    public class Delivery
    {
        public Delivery(CustomerData customerData, OrderData orderData)
        {
            customer = new Customer(customerData);
            order = Order.GetOrder(orderData);
        }
        public Customer customer { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public Order order { get; set; }
    }    
}

