﻿using MMTHSWebApp.DataObjects;
using Newtonsoft.Json;
namespace MMTHSWebApp.Models
{
    public class Delivery
    {
        public Delivery(Customer _customer, Order _order)
        {
            customer = _customer ;
            order = _order;
        }
        public Customer customer { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public Order order { get; set; }
    }    
}

