﻿using System;
using System.Net.Http;

namespace MMTHSWebApp.DataWebClient
{
    interface IWebDataService
    {
        T GetCustomerData<T>(string email) where T : class, new();
    }
    public class WebDataService
    {
        string url = "https://customer-details.azurewebsites.net/api/GetUserDetails";
        string apikey = "uu2ToG/dcsg3DI8CGlpLro1PyLhZNUWHpdPv8VmWFLBaxM0fvUZvkA==";
        //api key and url can be placed in web.config
        protected T GetData<T>(string email) where T : class, new()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var uri = new Uri(string.Format("{0}?code={1}&email={2}", url, apikey,email)); 
                    //client.BaseAddress = new Uri();
                    //HTTP GET

                    //var responseTask = client.GetAsync("GetUserDetails");
                    var responseTask = client.GetAsync(uri);
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {

                        var readTask = result.Content.ReadAsAsync<T>();
                        readTask.Wait();

                        return (T)readTask.Result;

                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Customer Data Not Available");
            }
            return null;
        }
    }    
}