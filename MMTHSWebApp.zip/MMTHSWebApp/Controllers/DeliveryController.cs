﻿using MMTHSWebApp.DataObjects;
using MMTHSWebApp.Models;
using MMTHSWebApp.Services;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MMTHSWebApp.Controllers
{
    public class DeliveryController : ApiController
    {
        private DeliveryRepository deliveryRepository;
        public DeliveryController()
        {
            this.deliveryRepository = new DeliveryRepository();
        }        
        // GET api/Delivery?user=cat.owner@mmtdigital.co.uk&customerID=C34454
        [HttpGet]
        public Delivery Get(string user, string customerID)
        {
            return GetDeliveryDetails(user, customerID);
        }
                
        [HttpPost]
        public Delivery Post(ForCustomer forCustomer) 
        {
            return GetDeliveryDetails(forCustomer.user, forCustomer.customerId);
        }

        private Delivery GetDeliveryDetails(string user, string customerID)
        {
            var customerInfo = new CustomerData().GetCustomerByUser(user);

            if (customerInfo.customerId != customerID)
            {
                var resp = new HttpResponseMessage(HttpStatusCode.NotFound )
                {
                    Content = new StringContent("Invalid Customer Detail."),
                    ReasonPhrase = "customerID Not Found"
                };
                throw new HttpResponseException(resp);
            }

            try
            {
                //return deliveryRepository.GetDelivery(customerInfo);  // catch can be implemented here  
                return new DeliveryServie().GetDelivery(customerInfo);
            }
            catch (Exception ex)
            {
                var resp = new HttpResponseMessage(HttpStatusCode.BadRequest)
                {
                    Content = new StringContent("Error Occured."),
                    ReasonPhrase = ex.Message 
                };
                throw new HttpResponseException(resp);
            }
        }
    }
}
 