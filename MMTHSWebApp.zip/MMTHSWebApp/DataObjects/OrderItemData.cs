﻿using MMTHSWebApp.DataConnection;
using System.Collections.Generic;

namespace MMTHSWebApp.DataObjects
{
    public class OrderItemData: DataService
    {
        public string product { get; set; }
        public int quantity { get; set; }
        public decimal priceEach { get; set; }
        public List<OrderItemData> GetOrderItems(OrderData orderData)
        {
            string sql = string.Format("select p.PRODUCTNAME as product, oi.QUANTITY as QUANTITY, oi.PRICE as priceEach from ORDERITEMS oi , PRODUCTS p where oi.PRODUCTID = p.PRODUCTID and oi.orderid = {0}", orderData.orderNumber);
            return GetData<OrderItemData>(sql);            
        }
    }
}