﻿using MMTHSWebApp.DataWebClient;

namespace MMTHSWebApp.DataObjects
{
    public class CustomerData : CustomerDataService
    {
        public string customerId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }

        public CustomerData GetCustomerById(string user)
        {
            return GetCustomerData<CustomerData>(user);
        }
    }
}