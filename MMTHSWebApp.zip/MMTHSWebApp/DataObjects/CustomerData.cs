﻿using MMTHSWebApp.DataWebClient;

namespace MMTHSWebApp.DataObjects
{
    public class CustomerData : WebDataService
    {
        public string customerId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }

        public CustomerData GetCustomerByUser(string user)
        {
            return GetData<CustomerData>(user);
        }
    }
}