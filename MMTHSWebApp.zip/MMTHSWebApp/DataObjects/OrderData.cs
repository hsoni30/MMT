﻿using MMTHSWebApp.DataConnection;
using System;
namespace MMTHSWebApp.DataObjects
{
    public class OrderData : DataService
    {
        public int orderNumber { get; set; }
        public DateTime orderDate { get; set; }
        public string deliveryAddress { get; set; }        
        public DateTime deliveryExpected { get; set; }        
        public bool CONTAINSGIFT { get; set; }

        public OrderData GetLatestOrder(CustomerData customerData)
        {
            string sql = string.Format("select CONTAINSGIFT , ORDERID as orderNumber, '' as deliveryAddress, * from ORDERS where CUSTOMERID = '{0}' and ORDERDATE = (select max(ORDERDATE) from ORDERS where CUSTOMERID = '{0}') ", customerData.customerId);
            return GetDataSingle<OrderData>(sql);           
        }
    }
}