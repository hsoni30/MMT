﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace MMTHSWebApp.DataConnection
{
    public class DataService
    {
        string connectionString = "Server=tcp:mmt-sse-test.database.windows.net,1433;Initial Catalog=SSE_Test;Persist Security Info=False;User ID=mmt-sse-test;Password=database-user-01;MultipleActiveResultSets=True;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        protected List<T> GetData<T>(string queryString) where T : class, new()
        { 
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Create the Command and Parameter objects.
                SqlCommand command = new SqlCommand(queryString, connection);
                
                try
                {
                    connection.Open();    
                    List<T> result = new List<T>();
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                var o = new T();
                                Type type = o.GetType();
                                PropertyInfo[] properties = type.GetProperties();

                                foreach (PropertyInfo property in properties)
                                {                                
                                    type.GetProperty(property.Name).SetValue(o, reader[property.Name], null);
                                }                               
                                result.Add(o);
                            }
                        }
                    }
                    return result;
                }
                catch (Exception ex)
                {
                    throw new Exception("Data Error.");
                }                
            }
         }       
    }
}