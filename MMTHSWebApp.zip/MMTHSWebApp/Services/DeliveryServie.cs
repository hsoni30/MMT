﻿using MMTHSWebApp.DataObjects;
using MMTHSWebApp.Models;

namespace MMTHSWebApp.Services
{
    public class DeliveryServie
    {
        public Delivery GetDelivery(CustomerData customerData)
        {
            var orderData = new OrderData().GetLatestOrder(customerData);
            
            var customer = new Customer(customerData);

            if (orderData != null) {
                var orderItemDatas = new OrderItemData().GetOrderItems(orderData);                
                var order =  new Order(orderData, orderItemDatas) ;
                return new Delivery(customer, order);
            }
            return new Delivery(customer, null);
        }
    }
}