﻿using MMTHSWebApp.DataConnection;
using MMTHSWebApp.DataObjects;
using MMTHSWebApp.DataWebClient;
using MMTHSWebApp.Models;
using System;
using System.Collections.Generic;

namespace MMTHSWebApp.Services
{
    public class DeliveryServie
    {
        public Delivery GetDelivery(CustomerData customerData)
        {
            var customer = new Customer(customerData);
            var delivery = new Delivery();
            delivery.customer = customer;

            var orderData = new OrderData().GetLatestOrder(customerData);    
            
            if (orderData != null)
            {               
                var order = new Order(orderData);
                delivery.order = order;

                var orderDataItems = new OrderItemData().GetOrderItems(orderData);
                List<OrderItem> orderItems = new List<OrderItem>();
                foreach (var orderitemData in orderDataItems) {
                    orderItems.Add(new OrderItem(orderitemData));
                }
                delivery.order.orderItems = orderItems.ToArray();
            }            

            return delivery;
        }
    }
}