﻿using MMTHSWebApp.DataObjects;
using MMTHSWebApp.Models;

namespace MMTHSWebApp.Services
{
    public class DeliveryServie
    {
        public Delivery GetDelivery(CustomerData customerData)
        {
            var orderData = new OrderData().GetLatestOrder(customerData);
            return new Delivery(customerData, orderData);
        }
    }
}