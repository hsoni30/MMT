﻿using System.Web;
using MMTHSWebApp.DataObjects;
using MMTHSWebApp.Models;

namespace MMTHSWebApp.Services
{
    public class DeliveryRepository
    {
        private const string CacheKeyPrefix = "DeliveryStore";       
        public Delivery GetDelivery(CustomerData customerData)
        {
            var ctx = HttpContext.Current;
            string CacheKey = CacheKeyPrefix + customerData.customerId;
            if (ctx != null)
            {
                if (ctx.Cache[CacheKey] != null)
                {
                    return (Delivery)ctx.Cache[CacheKey];
                }                
            }

            var delivery = new DeliveryServie().GetDelivery(customerData);
            
            ctx.Cache[CacheKey] = delivery;
            return   delivery ;                        
        }        
    }
}